#include <linux/unistd.h>
	
int main(){
	syscall(336, 5);
	return 1;
}
